package com.ACS560.HW7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HW7Application {
    public static void main(String[] args) {
        SpringApplication.run(HW7Application.class, args);
    }
}